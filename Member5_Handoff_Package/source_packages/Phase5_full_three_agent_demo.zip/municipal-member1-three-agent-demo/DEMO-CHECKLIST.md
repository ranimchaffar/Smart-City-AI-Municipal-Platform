# Member 1 — Full n8n demonstration checklist

**Required precondition:** Phase 4 running (`municipal-n8n`, `municipal-intake-stub`, `municipal-vision-stub`) and Docker network `municipal-net`.

## Start and verify service

In the extracted root folder (the folder containing `compose.yaml`):

```powershell
docker compose up -d
docker ps
curl.exe -i http://localhost:8003/health
```

The new `municipal-knowledge-stub` health endpoint should return `status:ok`, `rag_enabled:false`.

## Import and execute

In `http://localhost:5678`, create a new workflow. Import `n8n/municipal-ticket.json`, which is the same workflow as `n8n/municipal-ticket-phase5.json`. The Webhook path is `municipal-ticket-phase5`. Use `Citizen Webhook -> Listen for Test Event` before **each** request.

```powershell
curl.exe -i -X POST "http://localhost:5678/webhook-test/municipal-ticket-phase5" -H "Content-Type: application/json" --data-binary "@tests/fixtures/pass_pothole.json"
```

Expected: HTTP 200; `decision:PASS`, `ticket.category:ROAD_DAMAGE`, `ticket.department:ROADS_DEPARTMENT`, `ticket.persisted:false`, `versions.knowledge:knowledge-stub-v1`.

Repeat with each fixture after re-arming the test webhook:

| Fixture | Expected HTTP | Expected decision | Key reason |
|---|---:|---|---|
| `pass_pothole.json` | 200 | PASS | Simulated ticket only |
| `review_mismatch.json` | 202 | REVIEW | `IMAGE_TEXT_MISMATCH_OR_UNCLEAR` |
| `reject_missing_media.json` | 422 | REJECT | `MISSING_MEDIA_REF` |
| `knowledge_outage.json` | 202 | REVIEW | `KNOWLEDGE_ENDPOINT_FAILED_OR_INVALID` |
| `knowledge_wrong_id.json` | 202 | REVIEW | `KNOWLEDGE_REPORT_ID_MISMATCH` |
| `knowledge_empty_sources.json` | 202 | REVIEW | `MISSING_SOURCE` |

### Physical Knowledge outage / recovery

```powershell
docker stop municipal-knowledge-stub
```

Re-arm webhook; send `pass_pothole.json`: expected HTTP 202 REVIEW. Recover:

```powershell
docker start municipal-knowledge-stub
curl.exe http://localhost:8003/health
```

Re-arm webhook; send `pass_pothole.json`: expected HTTP 200 PASS.

### Local checks

```powershell
docker run --rm -v "${PWD}:/project" -w /project node:22-alpine node tests/check_phase5.mjs
```

Tests of JavaScript logic are separate from the real HTTP/n8n checks.

## For the professor

Say: "I designed and tested n8n orchestration across three independently callable agent interfaces: Intake, Vision and Knowledge. Three validation gates and fixed routing rules decide whether to create a ticket-ready response, ask for human review, or reject invalid input. The current agents and tickets are simulated: no real photo analysis, no source-grounded RAG and no persistent ticket storage yet."

Screenshots worth saving: full 20-node canvas, HTTP Knowledge output, Gate 3 accepted result, final PASS response, REVIEW outage response, REJECT response. Do not show invented official procedures as verified.

## Finish Member 1 integration afterwards

1. Agree on `docs/contracts.md` with Members 2-5.
2. Swap HTTP services for real endpoints and verify images are actually analyzed.
3. Implement durable ticket creation with Member 5 (`POST /tickets`, idempotent by `report_id`) and persistent audit events.
4. Add an n8n Error Trigger workflow, production authentication and minimized execution-data retention.
