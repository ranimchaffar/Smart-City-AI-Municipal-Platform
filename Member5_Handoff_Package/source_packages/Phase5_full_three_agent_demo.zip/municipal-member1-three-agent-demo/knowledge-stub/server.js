"use strict";
// DEMO ONLY: returns placeholder procedures. This is not RAG and no municipal documents are queried.
const http=require('node:http');
const PORT=Number(process.env.PORT || 8003);
const departments={ROAD_DAMAGE:'ROADS_DEPARTMENT',STREET_LIGHTING:'PUBLIC_LIGHTING_DEPARTMENT',WASTE:'SANITATION_DEPARTMENT',WATER_LEAK:'WATER_SERVICES_DEPARTMENT'};
function reply(res,status,data){
 const body=JSON.stringify(data);
 res.writeHead(status,{'content-type':'application/json; charset=utf-8','cache-control':'no-store','content-length':Buffer.byteLength(body)});
 res.end(body);
}
const server=http.createServer((req,res)=>{
 if(req.method==='GET'&&req.url==='/health')return reply(res,200,{status:'ok',service:'knowledge-stub',version:'knowledge-stub-v1',rag_enabled:false});
 if(req.method!=='POST'||req.url!=='/knowledge')return reply(res,404,{error:'NOT_FOUND'});
 if(!String(req.headers['content-type']||'').toLowerCase().includes('application/json'))return reply(res,415,{error:'JSON_REQUIRED'});
 let count=0,chunks=[];let rejected=false;
 req.on('data',piece=>{
  count+=piece.length;
  if(count>65536){if(!rejected){rejected=true;reply(res,413,{error:'BODY_TOO_LARGE'});}return;}
  chunks.push(piece);
 });
 req.on('end',()=>{
  if(rejected)return;
  let d;try{d=JSON.parse(Buffer.concat(chunks).toString('utf8'));}catch{return reply(res,400,{error:'INVALID_JSON'});}
  if(!d||typeof d!=='object'||Array.isArray(d)||typeof d.report_id!=='string'||
     !/^[A-Za-z0-9_-]{3,64}$/.test(d.report_id)||typeof d.category!=='string'||
     typeof d.department!=='string'||typeof d.description!=='string'||!d.description.trim())
    return reply(res,400,{error:'INVALID_KNOWLEDGE_REQUEST'});
  if(!departments[d.category]||departments[d.category]!==d.department) return reply(res,422,{error:'INVALID_ROUTING'});
  // Controlled negative-test cases. Identifiers are fictitious and used only in local demos.
  if(d.report_id==='RPT-KNOW-FAIL')return reply(res,503,{error:'SIMULATED_KNOWLEDGE_OUTAGE'});
  const id=d.report_id==='RPT-KNOW-WRONG'?'RPT-DIFFERENT-ID':d.report_id;
  const sources=d.report_id==='RPT-KNOW-EMPTY'?[]:[{
    document_title:'DEMO PLACEHOLDER - NOT MUNICIPAL POLICY',
    source_url:null,chunk_id:'mock-'+d.category.toLowerCase()+'-01',
    search_score:null,is_official:false,is_mock:true
  }];
  return reply(res,200,{
    report_id:id,category:d.category,department:d.department,
    procedure:'DEMO ONLY: send the report to '+d.department+' for human assessment. This is not an official municipal procedure.',
    sources,deadline:null,agent_version:'knowledge-stub-v1',is_mock:true
  });
 });
 req.on('error',()=>{if(!res.headersSent)res.end();});
});
if(require.main===module)server.listen(PORT,'0.0.0.0',()=>console.log('knowledge-stub on '+PORT));
module.exports={server};
