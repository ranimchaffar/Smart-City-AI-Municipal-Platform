import assert from 'node:assert/strict';
import fs from 'node:fs';
const root = new URL('../', import.meta.url);
const workflow = JSON.parse(fs.readFileSync(new URL('n8n/municipal-ticket-phase5.json',root),'utf8'));
const nodes = new Map(workflow.nodes.map(n=>[n.name,n]));
const code = name => {assert.ok(nodes.has(name),`missing ${name}`);return nodes.get(name).parameters.jsCode;};
function exec(name,input,base){
 const result = new Function('$input','$',code(name))(
  {first:()=>({json:structuredClone(input)})},
  key=>({first:()=>({json:structuredClone(base)})})
 );
 assert.ok(Array.isArray(result)&&result.length===1,`${name} must return 1 item`);
 return result[0].json;
}
const fixture=name=>JSON.parse(fs.readFileSync(new URL(`tests/fixtures/${name}`,root),'utf8'));
const fixtures=new Set(['mock://pothole','mock://streetlight','mock://waste','mock://water_leak','mock://unrelated','mock://blurry']);
function fakeIntake(d,ov={}){
 const f=fixtures.has(d.media_ref);
 return {report_id:d.report_id,input_type:'IMAGE_TEXT',cleaned_description:d.description,
  language:'en',media_ref:d.media_ref,anonymized_media_ref:null,
  media_validation:f?'MOCK_FIXTURE':'NOT_VERIFIED',privacy_status:'TEXT_MASKED_ONLY',
  image_anonymized:false,location:d.location??null,validity:f?'MOCK_VALID':'UNKNOWN',
  errors:f?[]:['REAL_MEDIA_NOT_PROCESSED'],agent_version:'intake-stub-v1',is_mock:true,...ov};
}
function fakeVision(d,ov={}){
 const cats={'mock://pothole':'ROAD_DAMAGE','mock://streetlight':'STREET_LIGHTING','mock://unrelated':'NONE'};
 const cat=cats[d.media_ref]||'NONE';
 const match=cat==='ROAD_DAMAGE'?/pothole|road/i.test(d.description):cat==='STREET_LIGHTING'?/streetlight|light|lamp/i.test(d.description):null;
 return {report_id:d.report_id,category:cat,severity:'HIGH',description:d.description,
  evidence:cat==='NONE'?[]:['DEMO fixture label only; pixels not analyzed'],
  text_image_consistent:match,confidence:null,uncertainty:match!==true,
  prompt_version:'vision-fixture-v1',agent_version:'vision-stub-v1',is_mock:true,...ov};
}
function fakeKnowledge(d,ov={}){
 return {report_id:d.report_id,category:'ROAD_DAMAGE',department:'ROADS_DEPARTMENT',
  procedure:'DEMO ONLY: human assessment. Not municipal policy.',
  sources:[{document_title:'DEMO PLACEHOLDER - NOT MUNICIPAL POLICY',source_url:null,
   chunk_id:'mock-road_damage-01',search_score:null,is_official:false,is_mock:true}],
  deadline:null,agent_version:'knowledge-stub-v1',is_mock:true,...ov};
}
function simulate(d,{intakeRaw,visionRaw,knowledgeRaw,intakeOverride={},visionOverride={},knowledgeOverride={},realMode=false}={}){
 let x=exec('Input Check',{body:d});
 if(x.decision==='PASS'){
  let previous=x;
  x=exec('Attach Intake Response',intakeRaw??fakeIntake(d,intakeOverride),previous);
  x=exec('Gate 1 - Intake',x);
  if(x.decision==='PASS'){
   previous=x;
   x=exec('Attach Vision Response',visionRaw??fakeVision(d,visionOverride),previous);
   x=exec('Gate 2 - Vision',x);
   if(x.decision==='PASS'){
    x=exec('Department Rules',x);
    previous=x;
    x=exec('Attach Knowledge Response',knowledgeRaw??fakeKnowledge(d,knowledgeOverride),previous);
    if(realMode)x.demo_mode=false;
    x=exec('Gate 3 - Sources',x);
    if(x.decision==='PASS')x=exec('Mock Ticket Creation',x);
   }
  }
 }
 x=exec('Audit Summary',x);
 x=exec('Format API Response',x);
 return x;
}
const pass=fixture('pass_pothole.json');
const mismatch=fixture('review_mismatch.json');
const missing=fixture('reject_missing_media.json');
const fakeMedia={...pass,report_id:'RPT-NO-REAL',media_ref:'uploads/picture.jpg'};
let count=0;
function check(title,d,opts,decision,status,reason){
 const r=simulate(d,opts);
 assert.equal(r.decision,decision,title);
 assert.equal(r.http_status,status,title);
 assert.equal(r.report_id,d.report_id,title);
 assert.equal(r.ticket===null,decision!=='PASS',title+' ticket');
 assert.equal(r.audit.outcome,decision,title);
 assert.ok(r.audit.stages.every(s=>!('media_ref' in s)&&!('description' in s)),title+' safe audit');
 if(reason)assert.ok(r.review_reasons.includes(reason)||r.errors.includes(reason),`${title} -> ${reason}`);
 if(decision==='PASS'){
  assert.equal(r.ticket.department,'ROADS_DEPARTMENT');
  assert.equal(r.ticket.persisted,false);
  assert.equal(r.versions.knowledge,'knowledge-stub-v1');
 }
 count++;console.log('PASS',title,decision,status);
}
check('valid pothole',pass,{},'PASS',200);
check('image/text mismatch',mismatch,{},'REVIEW',202,'IMAGE_TEXT_MISMATCH_OR_UNCLEAR');
check('required image missing',missing,{},'REJECT',422,'MISSING_MEDIA_REF');
check('intake outage',pass,{intakeRaw:{error:'UNAVAILABLE'}},'REVIEW',202,'INTAKE_ENDPOINT_FAILED_OR_INVALID');
check('intake wrong report',pass,{intakeOverride:{report_id:'BAD-REPORT'}},'REVIEW',202,'INTAKE_REPORT_ID_MISMATCH');
check('real image not validated',fakeMedia,{},'REVIEW',202,'INTAKE_MEDIA_OR_PRIVACY_NOT_VERIFIED');
check('vision outage',pass,{visionRaw:{error:'UNAVAILABLE'}},'REVIEW',202,'VISION_ENDPOINT_FAILED_OR_INVALID');
check('vision wrong report',pass,{visionOverride:{report_id:'BAD-REPORT'}},'REVIEW',202,'VISION_REPORT_ID_MISMATCH');
check('vision evidence missing',pass,{visionOverride:{evidence:[]}},'REVIEW',202,'VISION_MISSING_EVIDENCE');
check('knowledge outage',pass,{knowledgeRaw:{error:'UNAVAILABLE'}},'REVIEW',202,'KNOWLEDGE_ENDPOINT_FAILED_OR_INVALID');
check('knowledge wrong report',pass,{knowledgeOverride:{report_id:'BAD-REPORT'}},'REVIEW',202,'KNOWLEDGE_REPORT_ID_MISMATCH');
check('knowledge wrong category',pass,{knowledgeOverride:{category:'WASTE'}},'REVIEW',202,'KNOWLEDGE_CATEGORY_MISMATCH');
check('knowledge wrong department',pass,{knowledgeOverride:{department:'SANITATION_DEPARTMENT'}},'REVIEW',202,'KNOWLEDGE_DEPARTMENT_MISMATCH');
check('knowledge no procedure',pass,{knowledgeOverride:{procedure:''}},'REVIEW',202,'MISSING_PROCEDURE');
check('knowledge no sources',pass,{knowledgeOverride:{sources:[]}},'REVIEW',202,'MISSING_SOURCE');
check('knowledge bad chunk ID',pass,{knowledgeOverride:{sources:[{...fakeKnowledge(pass).sources[0],chunk_id:''}]}},'REVIEW',202,'INVALID_SOURCE_METADATA');
check('knowledge bad search score',pass,{knowledgeOverride:{sources:[{...fakeKnowledge(pass).sources[0],search_score:3}]}},'REVIEW',202,'INVALID_SEARCH_SCORE');
check('knowledge fakes official',pass,{knowledgeOverride:{sources:[{...fakeKnowledge(pass).sources[0],source_url:'https://example.gov/file',is_official:true,is_mock:false}],is_mock:false}},'REVIEW',202,'INVALID_DEMO_SOURCE');
check('knowledge invented deadline',pass,{knowledgeOverride:{deadline:'tomorrow'}},'REVIEW',202,'DEMO_DEADLINE_MUST_BE_NULL');
check('knowledge no agent version',pass,{knowledgeOverride:{agent_version:''}},'REVIEW',202,'KNOWLEDGE_VERSION_MISSING');
check('real mode never accepts stub',pass,{realMode:true},'REVIEW',202,'OFFICIAL_SOURCE_VERIFICATION_NOT_IMPLEMENTED');
// Graph and imported workflow invariants
assert.equal(nodes.size,20);assert.equal(nodes.get('Citizen Webhook').parameters.path,'municipal-ticket-phase5');
for(const [from,c] of Object.entries(workflow.connections)){
 assert.ok(nodes.has(from),from);
 for(const outgoing of c.main??[])for(const edge of outgoing)assert.ok(nodes.has(edge.node),from+' -> '+edge.node);
}
const reachable=new Set(),q=['Citizen Webhook'];
while(q.length){const n=q.shift();if(reachable.has(n))continue;reachable.add(n);
 for(const arr of workflow.connections[n]?.main??[])for(const edge of arr)q.push(edge.node);
}
assert.deepEqual(new Set(nodes.keys()),reachable);
for(const name of ['HTTP Intake','HTTP Vision','HTTP Knowledge']){
 const n=nodes.get(name);assert.equal(n.retryOnFail,true);assert.equal(n.maxTries,3);
 assert.equal(n.onError,'continueRegularOutput');
}
assert.equal(nodes.get('Citizen Webhook').parameters.responseMode,'responseNode');
assert.equal(nodes.get('Respond to Citizen').parameters.respondWith,'firstIncomingItem');
console.log(`All ${count} offline logic checks plus workflow graph validation passed.`);
