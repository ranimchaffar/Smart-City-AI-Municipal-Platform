import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);
const {server}=require('../knowledge-stub/server.js');
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const base=`http://127.0.0.1:${server.address().port}`;
const body={report_id:'RPT-001',category:'ROAD_DAMAGE',department:'ROADS_DEPARTMENT',description:'Large pothole in road',municipality:null};
async function post(payload){const res=await fetch(base+'/knowledge',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(payload)});return {status:res.status,json:await res.json()};}
try{
 let r=await fetch(base+'/health');assert.equal(r.status,200);assert.equal((await r.json()).rag_enabled,false);console.log('PASS health');
 let v=await post(body);assert.equal(v.status,200);assert.equal(v.json.is_mock,true);assert.equal(v.json.deadline,null);assert.equal(v.json.sources[0].is_official,false);console.log('PASS placeholder response');
 v=await post({...body,department:'NOT_A_DEPARTMENT'});assert.equal(v.status,422);console.log('PASS invalid route');
 v=await post({...body,report_id:'RPT-KNOW-FAIL'});assert.equal(v.status,503);console.log('PASS simulated outage');
 v=await post({...body,report_id:'RPT-KNOW-WRONG'});assert.notEqual(v.json.report_id,'RPT-KNOW-WRONG');console.log('PASS wrong-ID test fixture');
 v=await post({...body,report_id:'RPT-KNOW-EMPTY'});assert.equal(v.json.sources.length,0);console.log('PASS empty-source test fixture');
 console.log('All 6 Knowledge HTTP tests passed.');
} finally{await new Promise(resolve=>server.close(resolve));}
