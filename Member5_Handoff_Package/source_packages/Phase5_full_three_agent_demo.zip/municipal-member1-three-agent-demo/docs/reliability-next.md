# Member 1 — Next hardening priorities (after Phase 5)

1. **Durable event log:** Design `ticket_events` or `workflow_events` with `report_id`, `execution_id`, timestamp, stage, decision, reason codes, agent versions, and sanitized error class. Discuss with Member 5. Avoid storing raw descriptions or image bytes in the audit table.
2. **Unexpected n8n errors:** Add a separate Error Trigger workflow for unexpected execution failures and send sanitized alert metadata to an authenticated service. This complements (does not replace) the existing policy gates.
3. **Idempotent ticket persistence:** When Member 5 adds `POST /tickets`, use report ID as a unique idempotency key, with transaction-based duplicate handling; don't blindly retry state-changing POST requests.
4. **Real source registry:** Independently validate Knowledge source URL/document ID against approved sources for the selected municipality. Require real retrieved excerpt linkage and never invent deadlines.
5. **Media access:** Coordinate a secure, short-lived or private access mechanism for anonymized image bytes between Members 3 and 4. A `media_ref` string alone does not provide image content.
6. **Security:** Lock down webhook authentication, limit request size and rate, restrict exposure of ports (currently localhost only), disable unneeded saved execution payloads, and define data retention before real citizen inputs.
7. **Integration tests:** Re-run PASS, REVIEW, REJECT, agent outage/recovery, wrong ID, spoofed source and duplicate save cases after every service swap.

The current project is a **demonstration**, not a verified municipal decision system.
