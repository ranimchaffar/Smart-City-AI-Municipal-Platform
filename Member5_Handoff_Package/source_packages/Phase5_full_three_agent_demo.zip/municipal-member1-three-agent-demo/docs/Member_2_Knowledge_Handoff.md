# Member 2 — Knowledge/RAG API handoff from Member 1

**We already have a working HTTP connection in n8n.** Please replace the temporary Knowledge stub with your actual RAG service. Do not change field names without agreement.

## Endpoint

- Method: `POST`
- Path: `/knowledge`
- Content type: `application/json`
- For local Docker development, supply a service name on network `municipal-net`, e.g. `http://knowledge-agent:8000/knowledge` (this is only an example URL).
- Expose `GET /health` for diagnostics. Keep it stateless or discuss retries with Member 1.

## Request

```json
{
  "report_id":"RPT-001",
  "category":"ROAD_DAMAGE",
  "department":"ROADS_DEPARTMENT",
  "description":"A deep pothole on the roadway",
  "municipality":null
}
```

`municipality:null` is currently a placeholder. **Choose an actual municipality and trusted document corpus**, and agree on its identifier with the team before claiming real-source support. Department values here are internal demo labels, not verified official department names.

## Response (illustrative SHAPE, not a real source)

```json
{
  "report_id":"RPT-001",
  "category":"ROAD_DAMAGE",
  "department":"ROADS_DEPARTMENT",
  "procedure":"Short instructions strictly grounded in retrieved source text",
  "sources":[{
    "document_title":"Actual title from verified document",
    "source_url":"https://example.gov/actual-document-url-when-verified",
    "chunk_id":"road-001",
    "search_score":0.83,
    "is_official":true,
    "is_mock":false
  }],
  "deadline":null,
  "agent_version":"knowledge-v1",
  "is_mock":false
}
```

The URL is illustrative. **Do not claim this document exists**. The `is_official` field is a claim that the orchestration must verify independently, not proof of authority.

## Acceptance tests

1. A pothole query returns matching document excerpt(s), title, real URL, chunk ID and search score. Never invent deadlines.
2. A no-answer or weak-evidence query does not fabricate a procedure or source. Return an explicit insufficient-evidence result; Member 1 will route it to REVIEW.
3. A wrong report ID or category is never accepted by n8n.
4. A source for the wrong municipality must be excluded.
5. Provide a small retrieval evaluation: expected source, first match, top-3 match, and no-answer cases.
6. Demonstrate grounding: the procedure should only express what retrieved documents support.

## Technical dependencies and handoff

Please share: Docker Compose/service details; endpoint URL; corpus `sources.csv` with titles and original links; Qdrant collection and embedding model; response schema; 5+ labeled RAG questions; no-answer test; a short experiment note on chunking; Knowledge Agent prompt version(s).

**Current n8n status:** `HTTP Knowledge` -> `Attach Knowledge Response` -> `Gate 3 - Sources` is in place. This stub is NOT RAG. Real-source PASS is deliberately disabled until Member 1 adds an independently verified allowlist for the selected municipality. We will not simply trust `is_official:true`.
