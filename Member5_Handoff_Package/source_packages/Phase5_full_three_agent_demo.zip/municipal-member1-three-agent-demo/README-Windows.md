# Member 1 — Phase 5: HTTP Knowledge (Windows 11)

You already have a working **Phase 4** installation: `municipal-n8n`, `municipal-intake-stub`, `municipal-vision-stub`, and external Docker network `municipal-net`.

**This package starts only one additional container, `municipal-knowledge-stub`**. It leaves your running Phase 4 containers and workflows untouched. This is a **transport / validation demo, not a real Retrieval-Augmented Generation system**. No documents are ingested or searched; procedures are placeholders, explicitly marked `is_mock:true`, `is_official:false`, and `deadline:null`.

## 0. First finish service recovery (Phase 4)

Open PowerShell and run:

```powershell
docker start municipal-vision-stub
curl.exe -i http://localhost:8002/health
```

Expect HTTP 200 and `status:"ok"`. In Phase 4 n8n, click `Citizen Webhook` -> `Listen for Test Event`; from the Phase 4 extracted folder run:

```powershell
curl.exe -i -X POST "http://localhost:5678/webhook-test/municipal-ticket-phase4" -H "Content-Type: application/json" --data-binary "@tests/fixtures/pass_pothole.json"
```

Expect HTTP 200 `PASS`, category `ROAD_DAMAGE`, and department `ROADS_DEPARTMENT`. If the service is healthy but the workflow still responds REVIEW, inspect `HTTP Vision` and `Gate 2 - Vision` before continuing.

## 1. Start new Knowledge service

Extract this ZIP. Open the *inner* `municipal-phase5` folder containing `compose.yaml` in File Explorer. In its address bar type `powershell` and press Enter.

```powershell
docker ps
docker network inspect municipal-net
docker compose up -d
curl.exe -i http://localhost:8003/health
```

Expected: HTTP 200 and JSON such as:

```json
{"status":"ok","service":"knowledge-stub","version":"knowledge-stub-v1","rag_enabled":false}
```

On this computer, `n8n` must be on the same `municipal-net` network. If it isn't, attach it:

```powershell
docker network connect municipal-net municipal-n8n
```

If Docker says the network connection already exists, don't repeat it. Check internal DNS if necessary:

```powershell
docker run --rm --network municipal-net curlimages/curl:latest http://municipal-knowledge-stub:8003/health
```

## 2. Import new workflow without overwriting Phase 4

Go to <http://localhost:5678>. Create a new workflow and from the three-dot menu choose `Import from File`. Select `n8n/municipal-ticket-phase5.json`. Save the new workflow. Keep Phase 4 as a backup.

The new workflow has **20 nodes**. New section:

`Department Rules -> HTTP Knowledge -> Attach Knowledge Response -> Gate 3 - Sources`

Inspect:

| Node | Required |
|---|---|
| Citizen Webhook | POST `/municipal-ticket-phase5`, respond through response node |
| HTTP Intake | `http://municipal-intake-stub:8001/intake` |
| HTTP Vision | `http://municipal-vision-stub:8002/vision` |
| HTTP Knowledge | `http://municipal-knowledge-stub:8003/knowledge`, POST JSON |
| HTTP Knowledge retry | max 3 total attempts; 1000 ms wait; timeout 8000 ms; continue into validation on error |
| Gate 3 - Sources | checks report ID, category, department, procedure and source metadata |
| Respond to Citizen | `First Incoming Item`; dynamic HTTP code from `http_status` |

These HTTP agent requests are designed to be stateless and safe to retry. Do **not** enable blind retries for real ticket writes without an idempotency key.

## 3. Live integration checks

Before **each** request click `Listen for Test Event` in the new workflow's Citizen Webhook node. PowerShell must be open in this Phase 5 folder.

### A. Valid demo fixture -> PASS / HTTP 200

```powershell
curl.exe -i -X POST "http://localhost:5678/webhook-test/municipal-ticket-phase5" -H "Content-Type: application/json" --data-binary "@tests/fixtures/pass_pothole.json"
```

Expect `decision:PASS`, demo ticket with `persisted:false`, `versions.knowledge:"knowledge-stub-v1"`. Inspect `HTTP Knowledge`, `Attach Knowledge Response`, `Gate 3 - Sources`. The `procedure` is deliberately labeled DEMO ONLY.

### B. Simulated Knowledge HTTP 503 -> REVIEW / HTTP 202

```powershell
curl.exe -i -X POST "http://localhost:5678/webhook-test/municipal-ticket-phase5" -H "Content-Type: application/json" --data-binary "@tests/fixtures/knowledge_outage.json"
```

Expect `decision:REVIEW`, `ticket:null`, `KNOWLEDGE_ENDPOINT_FAILED_OR_INVALID`.

### C. Knowledge returns wrong report ID -> REVIEW / HTTP 202

```powershell
curl.exe -i -X POST "http://localhost:5678/webhook-test/municipal-ticket-phase5" -H "Content-Type: application/json" --data-binary "@tests/fixtures/knowledge_wrong_id.json"
```

Expect reason `KNOWLEDGE_REPORT_ID_MISMATCH`.

### D. Knowledge returns no sources -> REVIEW / HTTP 202

```powershell
curl.exe -i -X POST "http://localhost:5678/webhook-test/municipal-ticket-phase5" -H "Content-Type: application/json" --data-binary "@tests/fixtures/knowledge_empty_sources.json"
```

Expect reason `MISSING_SOURCE` (and possibly `INVALID_DEMO_SOURCE`).

### E. Physical outage test

```powershell
docker stop municipal-knowledge-stub
```

Repeat Test A: HTTP 202 REVIEW, `KNOWLEDGE_ENDPOINT_FAILED_OR_INVALID`. Recover:

```powershell
docker start municipal-knowledge-stub
curl.exe -i http://localhost:8003/health
```

Repeat Test A. Expect HTTP 200 PASS. This demonstrates safe outage handling and recovery.

### F. Regression tests

Run original REVIEW and REJECT fixtures on the new webhook path. They should still be HTTP 202 and 422 respectively:

```powershell
curl.exe -i -X POST "http://localhost:5678/webhook-test/municipal-ticket-phase5" -H "Content-Type: application/json" --data-binary "@tests/fixtures/review_mismatch.json"
```

Click Listen again, then:

```powershell
curl.exe -i -X POST "http://localhost:5678/webhook-test/municipal-ticket-phase5" -H "Content-Type: application/json" --data-binary "@tests/fixtures/reject_missing_media.json"
```

## 4. Optional offline test suite

No Node.js installation is needed on Windows: Docker runs it:

```powershell
docker run --rm -v "${PWD}:/project" -w /project node:22-alpine node tests/check_phase5.mjs
```

Expected: `All 21 offline logic checks plus workflow graph validation passed.`

```powershell
docker run --rm -v "${PWD}:/project" -w /project node:22-alpine node tests/test_knowledge_stub.mjs
```

Expected: 6 Knowledge HTTP tests pass. These are **local tests**, not substitutes for live n8n execution.

## 5. Member 2 integration and safety notes

Send `docs/Member_2_Knowledge_Handoff.md` and `docs/contracts.md` to Member 2. The real Knowledge service will need document ingestion, source URLs, chunk IDs, search scores, filters for municipality and category, and a no-answer state. The current Knowledge Gate intentionally **cannot PASS real municipal sources** until we add independent municipality-specific source registry verification and a secure real-mode switch. Do not bypass this protection by setting `demo_mode` in a citizen request: the workflow ignores caller-supplied demo flags.

**Other unfinished work:** real photo processing from Member 3, real image inference from Member 4, permanent audit/event storage and idempotent ticket creation with Member 5. The current n8n `Audit Summary` is **not durable storage**. The full input may exist in n8n execution history; use fictitious reports only. Before real citizens: authentication, upload validation, private storage, retention policy, secrets, rate limits, and review queue.

## Troubleshooting

- Could not connect to Knowledge: `docker ps`, `curl.exe http://localhost:8003/health`, and `docker network inspect municipal-net`.
- Curl cannot find fixture file: navigate in PowerShell to the folder containing `tests`.
- 404 webhook: open the Phase 5 workflow and click Listen; verify `/webhook-test/municipal-ticket-phase5`.
- A HTTP node succeeded but Gate 3 returned REVIEW: check report IDs, routing fields, source metadata and `is_mock` flags. This is normal for bad/mismatched data.
- Old workflow stopped working: Phase 5 uses a different webhook path and only starts a new service. Check `docker ps -a` before changing existing containers.
