# Start here — Member 1 Full Three-Agent n8n Demo

This is the previously prepared Phase 5 workflow **with the missing architecture research file and an end-to-end demo checklist added**. It is meant to be installed **after the already-working Phase 4**; it does not replace existing containers or working workflows.

- Start with `README-Windows.md` to start the Knowledge stub and import `n8n/municipal-ticket.json`.
- Follow `DEMO-CHECKLIST.md` to verify live PASS, REVIEW, REJECT, Knowledge failures and recovery.
- `docs/research/architecture.md` explains research, node choices, safety, the sequential-vs-master-agent decision, and limitations.
- `docs/contracts.md` is the proposal to share with Members 2-5. Real agent endpoints must conform before the final integration.

**Scope:** Complete 3-agent **demo orchestration** with simulated ticket formatting, not real RAG, multimodal image inference or persistence. Do not use real citizens' sensitive data.
