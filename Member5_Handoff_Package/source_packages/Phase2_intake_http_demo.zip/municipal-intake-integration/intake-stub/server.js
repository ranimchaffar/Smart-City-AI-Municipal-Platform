'use strict';
// Contract-compatible HTTP *stub* for Member 1 integration tests.
// It NEVER opens images, detects faces, or claims that real media were verified.
const http = require('node:http');
const PORT = 8001;
const knownFixtures = new Set([
  'mock://pothole', 'mock://streetlight', 'mock://waste',
  'mock://water_leak', 'mock://unrelated', 'mock://blurry'
]);
function send(res, status, obj) {
  const payload = JSON.stringify(obj);
  res.writeHead(status, {'content-type':'application/json; charset=utf-8',
                         'cache-control':'no-store',
                         'content-length':Buffer.byteLength(payload)});
  res.end(payload);
}
function cleaned(s) {
  return s.replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, '[EMAIL_REDACTED]')
          .replace(/(?:\+?\d[\d ().-]{7,}\d)/g, '[PHONE_REDACTED]');
}
const server = http.createServer((req,res) => {
  if (req.method==='GET' && req.url==='/health') {
    return send(res, 200, {status:'ok', service:'intake-stub', version:'intake-stub-v1'});
  }
  if (req.method!=='POST' || req.url!=='/intake') return send(res, 404, {error:'NOT_FOUND'});
  if (!String(req.headers['content-type']||'').toLowerCase().includes('application/json')) {
    return send(res,415,{error:'JSON_REQUIRED'});
  }
  let raw=''; let exceeded=false;
  req.on('data',c=>{ raw+=c; if(Buffer.byteLength(raw)>65536) {exceeded=true;req.destroy();}});
  req.on('end',()=>{
    if(exceeded) return;
    let d;
    try {d=JSON.parse(raw);} catch {return send(res,400,{error:'INVALID_JSON'});}
    if (!d || typeof d!=='object' || Array.isArray(d) || typeof d.report_id!=='string' ||
        typeof d.description!=='string' || typeof d.media_ref!=='string') {
      return send(res,400,{error:'MISSING_FIELDS'});
    }
    if (d.media_ref==='mock://fail503') return send(res,503,{error:'SIMULATED_INTAKE_OUTAGE'});
    const fixture=knownFixtures.has(d.media_ref);
    const id=d.media_ref==='mock://wrongid' ? 'WRONG-REPORT-ID' : d.report_id;
    // No file access and no real image anonymization occur here.
    return send(res,200,{
      report_id:id,
      input_type:'IMAGE_TEXT',
      cleaned_description:cleaned(d.description),
      language:'und',
      media_ref:d.media_ref,
      anonymized_media_ref:null,
      media_validation:fixture?'MOCK_FIXTURE':'NOT_VERIFIED',
      privacy_status:'TEXT_MASKED_ONLY',
      image_anonymized:false,
      location:d.location??null,
      validity:fixture?'MOCK_VALID':'UNKNOWN',
      errors:fixture?[]:['REAL_MEDIA_NOT_PROCESSED'],
      agent_version:'intake-stub-v1',
      is_mock:true
    });
  });
  req.on('error',()=>{if(!res.headersSent)res.end();});
});
server.listen(PORT,'0.0.0.0',()=>console.log(`intake-stub listening on ${PORT}`));
