# Member 1 — HTTP Intake integration (Windows 11 + Docker + n8n)

**This is a separate integration experiment.** Do not delete or overwrite your working original municipal workflow. All three earlier tests should continue to work in the original workflow.

This package adds one real **HTTP connection** from n8n to a separately running Intake stub, which follows the team's JSON contract. It **does not validate real photo bytes, anonymize images, use a vision model, verify municipal sources, or save tickets.**

## What's in the package

- `compose.yaml` — starts a tiny Intake HTTP service using Docker (no Node.js installation required on Windows).
- `intake-stub/server.js` — a dependency-free, local-only demo Intake endpoint.
- `n8n/municipal-ticket-http-intake.json` — separate 17-node n8n workflow (new path `/municipal-ticket-intake`).
- `docs/contracts.md` — existing shared API contract (copy for Member 3).
- `tests/fixtures/*.json` — PASS/REVIEW/REJECT inputs.
- `tests/review_service_down.json` — tests 503 service failure converted to REVIEW.
- `tests/review_unverified_real.json` — shows a real reference cannot pass without actual verification.
- `tests/review_wrong_id.json` — tests mismatch between request and Intake result.

## A. Start the Intake stub

1. Extract this ZIP into a folder, such as `Downloads/municipal-intake-integration`.
2. Open that folder in File Explorer, click the address bar, enter `powershell`, and press Enter.
3. Run the following commands (Docker Desktop must already be running):

```powershell
docker network create municipal-net
docker network connect municipal-net municipal-n8n
docker compose up -d
```

If the network/connection already exists, Docker reports an 'already exists' error: skip that command and continue. Your original `municipal-n8n` container is not restarted or modified, except that it gets access to the new private Docker network.

4. Verify from Windows:

```powershell
docker ps
curl.exe http://localhost:8001/health
```

Expected result: `{"status":"ok","service":"intake-stub","version":"intake-stub-v1"}`.

5. Verify that your **n8n container** can reach the service by its Docker name (optional, but very useful):

```powershell
docker run --rm --network municipal-net curlimages/curl:latest http://municipal-intake-stub:8001/health
```

That second test does not require a `curl` installation inside n8n.

## B. Import as a NEW workflow

1. Open `http://localhost:5678`.
2. Make a new workflow; don't edit your original PASS/REVIEW/REJECT workflow.
3. From the top-right three-dot menu choose `Import from File`, then choose `n8n/municipal-ticket-http-intake.json`.
4. Save it. In this version, the `Input PASS?` node goes to `HTTP Intake`, then `Attach Intake Response`, then `Gate 1 - Intake`. The rest of the sequence is unchanged.
5. Open `HTTP Intake` and check:
   - Method = POST
   - URL = `http://municipal-intake-stub:8001/intake`
   - Send Body = ON, Body Content Type = JSON, Using JSON
   - On Error = Continue (the incoming response/error is checked safely by the adapter)
   - Timeout = 5000 ms
6. Open `Citizen Webhook` and choose `Listen for Test Event`.

**Why a Docker name, not localhost?** Each container has its own network namespace. Inside n8n, `localhost` refers to the n8n container, not your Intake container. The shared Docker network lets n8n use the hostname `municipal-intake-stub`.

## C. Run four tests (PowerShell from this folder)

Click `Listen for Test Event` again before **each** request, then run one command:

```powershell
# PASS: verified demo fixture via HTTP stub, still not a real image
curl.exe -i -X POST "http://localhost:5678/webhook-test/municipal-ticket-intake" -H "Content-Type: application/json" --data-binary "@tests/fixtures/pass_pothole.json"

# REVIEW: stub emits fixture but the simulated Vision agent detects mismatch
curl.exe -i -X POST "http://localhost:5678/webhook-test/municipal-ticket-intake" -H "Content-Type: application/json" --data-binary "@tests/fixtures/review_mismatch.json"

# REJECT: no media ref; HTTP Intake must NOT execute
curl.exe -i -X POST "http://localhost:5678/webhook-test/municipal-ticket-intake" -H "Content-Type: application/json" --data-binary "@tests/fixtures/reject_missing_media.json"

# REVIEW: Intake API returns HTTP 503; must NOT auto-create a ticket
curl.exe -i -X POST "http://localhost:5678/webhook-test/municipal-ticket-intake" -H "Content-Type: application/json" --data-binary "@tests/review_service_down.json"
```

Expected outcomes: 200 PASS with `ROAD_DAMAGE` and `ROADS_DEPARTMENT` and `persisted:false`; 202 REVIEW and no ticket; 422 REJECT and no ticket; 202 REVIEW with no ticket for HTTP 503. Response includes a trace, versions and `demo_mode:true`.

Also test unverified real media refs and report-ID mismatch — both must REVIEW:

```powershell
curl.exe -i -X POST "http://localhost:5678/webhook-test/municipal-ticket-intake" -H "Content-Type: application/json" --data-binary "@tests/review_unverified_real.json"
curl.exe -i -X POST "http://localhost:5678/webhook-test/municipal-ticket-intake" -H "Content-Type: application/json" --data-binary "@tests/review_wrong_id.json"
```

## D. How this works

- `HTTP Intake` sends only the four fields in `docs/contracts.md`, not internal routing state or audit data.
- `Attach Intake Response` restores the original report state after n8n replaces the item with the HTTP response. Missing, malformed, or error responses become REVIEW.
- `Gate 1 - Intake` checks response ID, media ref, description, and exact fixture/real privacy requirements. For demo fixture PASS, it requires the known mock validation flags. For future real media PASS, it requires `VERIFIED`, `VALID`, `ANONYMIZED`, `image_anonymized:true`, and safe anonymized media ref. All other cases go to REVIEW.
- `Mock Vision`, `Mock Knowledge` and `Mock Ticket Creation` remain simulated. All return values identify the demo and do not claim real ticket persistence.

## E. When Member 3's real service is ready

Ask Member 3 for:
1. Reachable Docker-network URL or hostname, e.g. `http://intake-agent:8000/intake`.
2. POST request example + real JSON response matching section C of `docs/contracts.md`.
3. How `uploads/...` references map to controlled image storage; do **not** let Intake fetch arbitrary URLs.
4. How real input image bytes are validated and anonymized, plus tests for corrupt images and faces.
5. Error responses and agent_version.

Replace the URL in `HTTP Intake` once the real service can be reached from n8n. The mock workflow must not be used as proof of real image validation. With the Vision stage still mocked, a real uploaded image will stop at Gate 2 as REVIEW until Member 4 is connected.

## F. Troubleshooting

- `ECONNREFUSED` or DNS error: check `docker ps` and `docker network inspect municipal-net`. Ensure both containers are on the same Docker network.
- `HTTP Intake` outputs only agent fields: correct. `Attach Intake Response` restores `input`, `trace`, and `versions`.
- 503: demo intentionally returns a 503 for `mock://fail503`. n8n should return REVIEW.
- Workflow imported but not running: confirm the URL ends in `/municipal-ticket-intake`, the **new** path.
- If `municipal-intake-stub` isn't running: `docker compose up -d` (inside folder) and `docker compose logs intake-stub`.

To stop just this Intake stub, run `docker compose down` from this folder. Your original n8n container remains running.

## Security limits

Use only fictitious reports/fixture IDs for this local lab. The webhook has no authentication or abuse prevention and n8n may store execution data. Real citizen photos require privacy review, access controls and retention rules before testing.
