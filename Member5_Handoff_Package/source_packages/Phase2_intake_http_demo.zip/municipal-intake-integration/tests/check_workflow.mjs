import assert from 'node:assert/strict';
import fs from 'node:fs';
const workflow = JSON.parse(fs.readFileSync(new URL('../n8n/municipal-ticket-http-intake.json',import.meta.url),'utf8'));
const code = n => workflow.nodes.find(x=>x.name===n).parameters.jsCode;
const exec = (name, item, base) => {
  const fn = new Function('$input','$',code(name));
  return fn({first:()=>({json:item})},()=>({first:()=>({json:base})}))[0].json;
};
const fixture = (file) => JSON.parse(fs.readFileSync(new URL(file,import.meta.url),'utf8'));
function initial(d){return {report_id:d.report_id,input:{description:d.description,media_ref:d.media_ref,location:d.location??null},demo_mode:true,decision:'PASS',errors:[],review_reasons:[],trace:[],versions:{}};}
function result(d, changes={}) {
 const fixture = ['mock://pothole','mock://streetlight'].includes(d.media_ref);
 return {report_id:d.report_id,input_type:'IMAGE_TEXT', cleaned_description:d.description,
         media_ref:d.media_ref, media_validation:fixture?'MOCK_FIXTURE':'NOT_VERIFIED',
         validity:fixture?'MOCK_VALID':'UNKNOWN', privacy_status:'TEXT_MASKED_ONLY',
         anonymized_media_ref:null,image_anonymized:false,errors:fixture?[]:['REAL_MEDIA_NOT_PROCESSED'],
         agent_version:'intake-stub-v1',is_mock:true,...changes};
}
let tests=0;
const cases = [
  ['fixtures/pass_pothole.json', {},'PASS'],
  ['fixtures/review_mismatch.json', {},'PASS'], // mismatch handled later by Vision gate
  ['review_unverified_real.json', {},'REVIEW'],
  ['review_unverified_real.json', {is_mock:false,media_validation:'VERIFIED',validity:'VALID',privacy_status:'ANONYMIZED',image_anonymized:true,anonymized_media_ref:'safe/example.jpg',errors:[]},'PASS'],
  ['review_wrong_id.json', {report_id:'WRONG-REPORT-ID'},'REVIEW'],
  ['review_service_down.json', {error:'SIMULATED_INTAKE_OUTAGE'},'REVIEW']
];
for (const [file,changes,expected] of cases){
 let d=fixture(file),base=initial(d);
 let resp = file==='review_service_down.json' ? {error:'SIMULATED_INTAKE_OUTAGE'} : result(d,changes);
 let attached=exec('Attach Intake Response',resp,base);
 let judged=exec('Gate 1 - Intake',attached);
 assert.equal(judged.decision,expected,file);
 assert.equal(judged.report_id,d.report_id);
 assert.ok(Array.isArray(judged.trace) && judged.trace.length===2);
 if(expected==='REVIEW') assert.ok(judged.review_reasons.length>0);
 console.log('OK',file,judged.decision);
 tests++;
}
assert.equal(workflow.nodes.length,17);
assert.equal(workflow.nodes.find(x=>x.name==='Citizen Webhook').parameters.path,'municipal-ticket-intake');
assert.equal(workflow.nodes.find(x=>x.name==='HTTP Intake').onError,'continueRegularOutput');
console.log(`Static node+adapter checks passed: ${tests} cases; n8n live import not executed here.`);
