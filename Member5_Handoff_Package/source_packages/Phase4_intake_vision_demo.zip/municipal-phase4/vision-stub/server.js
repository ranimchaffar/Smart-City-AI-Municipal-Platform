"use strict";
// DEMO ONLY: keyword/fixture classification, no image bytes ever opened or processed.
const http=require('node:http');
const PORT=Number(process.env.PORT || 8002);
const fixtureCategory={
  'mock://pothole':'ROAD_DAMAGE','mock://streetlight':'STREET_LIGHTING',
  'mock://waste':'WASTE','mock://water_leak':'WATER_LEAK',
  'mock://unrelated':'NONE','mock://blurry':'NONE'
};
const patterns={
  ROAD_DAMAGE:/\b(pothole|road|asphalt|pavement)\b|nid[s]?[- ]de[- ]poule/i,
  STREET_LIGHTING:/\b(streetlight|street light|lamp|lighting|lamppost)\b|lampadaire|éclairage/i,
  WASTE:/\b(trash|garbage|waste|rubbish|bin)\b|déchet|ordure/i,
  WATER_LEAK:/\b(water|leak|pipe|flood)\b|fuite|eau/i
};
function reply(res,status,data){
 const payload=JSON.stringify(data);
 res.writeHead(status,{'content-type':'application/json; charset=utf-8','cache-control':'no-store','content-length':Buffer.byteLength(payload)});
 res.end(payload);
}
http.createServer((req,res)=>{
 if(req.method==='GET'&&req.url==='/health')return reply(res,200,{status:'ok',service:'vision-stub',version:'vision-stub-v1'});
 if(req.method!=='POST'||req.url!=='/vision')return reply(res,404,{error:'NOT_FOUND'});
 if(!String(req.headers['content-type']||'').toLowerCase().includes('application/json'))return reply(res,415,{error:'JSON_REQUIRED'});
 let total=0,chunks=[];
 req.on('data',part=>{total+=part.length;if(total<=65536)chunks.push(part);else{chunks=[];reply(res,413,{error:'BODY_TOO_LARGE'});req.destroy();}});
 req.on('end',()=>{
  if(total>65536)return;
  let d;
  try{d=JSON.parse(Buffer.concat(chunks).toString('utf8'));}catch{return reply(res,400,{error:'INVALID_JSON'});}
  if(!d||typeof d!=='object'||Array.isArray(d)||typeof d.report_id!=='string'||
     typeof d.cleaned_description!=='string'||typeof d.media_ref!=='string')return reply(res,400,{error:'MISSING_FIELDS'});
  const category=fixtureCategory[d.media_ref]||'NONE';
  const match=category==='NONE'?null:patterns[category].test(d.cleaned_description);
  const severity=/\b(dangerous|deep|severe|urgent|large|major)\b/i.test(d.cleaned_description)?'HIGH':'MEDIUM';
  return reply(res,200,{
    report_id:d.report_id,category,severity,
    description:d.cleaned_description,
    evidence:category==='NONE'?[]:['DEMO fixture label only; no image pixels were analyzed'],
    text_image_consistent:match,confidence:null,
    uncertainty:match!==true,
    prompt_version:'vision-fixture-v1',agent_version:'vision-stub-v1',is_mock:true
  });
 });
 req.on('error',()=>{if(!res.headersSent)res.end();});
}).listen(PORT,'0.0.0.0',()=>console.log('vision-stub on '+PORT));
