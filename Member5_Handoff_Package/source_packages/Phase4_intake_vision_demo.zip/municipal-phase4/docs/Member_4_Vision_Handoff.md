# Message / technical handoff to Member 4 — Real Vision Agent

Our Member 1 orchestration can now call **HTTP Vision** after the Intake privacy gate. The current `municipal-vision-stub` is only a network/fixture simulator; it never opens images or analyzes pixels.

## Your deliverable

Please provide a real `POST /vision` HTTP endpoint and a runnable Docker setup reachable from `municipal-n8n` on Docker network `municipal-net`. Send me the URL, sample request/response, how to start it, and a sample image that demonstrates a correct category and visible evidence.

### Request body from n8n

```json
{
  "report_id":"RPT-REAL-001",
  "media_ref":"safe/report001.jpg",
  "cleaned_description":"A pothole on the road",
  "location":null
}
```

`media_ref` refers to the **sanitized** image made available by Member 3. You must coordinate with Member 3 on how your container reads the actual image bytes securely. Do not fetch arbitrary user URLs. The reference string alone is not an image.

### Required JSON response

```json
{
  "report_id":"RPT-REAL-001",
  "category":"ROAD_DAMAGE",
  "severity":"HIGH",
  "description":"Pothole visible on the road surface",
  "evidence":["Visible broken asphalt and road-surface depression"],
  "text_image_consistent":true,
  "confidence":0.88,
  "uncertainty":false,
  "prompt_version":"v3",
  "agent_version":"vision-v1",
  "is_mock":false
}
```

This is a **schema example only**, not a claim that a model actually obtained this evidence or confidence. Output actual evidence from image analysis, or express uncertainty. Confidence can be a number from 0 to 1 or null; it is not proof of correctness.

Category must be exactly one of `ROAD_DAMAGE`, `STREET_LIGHTING`, `WASTE`, `WATER_LEAK`, `NONE`. Severity must be `LOW`, `MEDIUM`, or `HIGH` when supported; if uncertain, use `uncertainty:true`, `text_image_consistent:null`, and send enough details to justify REVIEW. Do not invent evidence when an image is unclear or absent. Maintain an agent version and prompt version in every response.

## Gate 2 acceptance conditions

My n8n gate checks:

- `report_id` exactly matches the original request.
- Category and severity are allowed values.
- `text_image_consistent === true` and `uncertainty === false` for an automatic PASS.
- Nonempty descriptive `evidence` array and nonempty `description` string.
- A valid `agent_version` string, and any returned `confidence` is between 0 and 1.
- For real media references, the endpoint must return `is_mock:false`; fixture-style outputs cannot count as verified real photos.

If any condition fails, n8n returns **REVIEW, not PASS**. The department will still be chosen by fixed Member 1 rules; the Vision Agent should not decide departments.

## Tests I need before integration

1. Actual pothole photo with matching text -> `ROAD_DAMAGE`, documented visual evidence.
2. Streetlight photo with pothole text -> mismatch / uncertainty; REVIEW in n8n.
3. Irrelevant or blurry photo -> `NONE` or uncertainty; REVIEW in n8n.
4. Invalid/unreadable image -> clear error response; never invented evidence.
5. Wrong report ID and malformed JSON handling -> rejected by Gate 2.
6. Repeat requests / timeout behavior: tell me whether retries are safe and what timeouts your model needs.

**Important:** If Intake is still a demo stub, real-image tests will stop at Gate 1, as intended. Coordinate with Member 3 for real validated media before expecting an end-to-end real-image PASS.

Our demo's HTTP Vision target is `http://municipal-vision-stub:8002/vision`. We will swap only the URL when your implementation is ready and rerun regression tests. Never put API keys in exported workflow files.
