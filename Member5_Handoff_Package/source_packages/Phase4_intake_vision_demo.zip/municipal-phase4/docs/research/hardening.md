# Member 1 research notes — Phase 4 integration and robustness

## Why a sequential n8n orchestrator?

The project has three cooperating agents, but their outputs have distinct meanings and safety boundaries: Intake validates/privacy-cleans the evidence, Vision assesses visual content, Knowledge retrieves municipal source material. A fixed sequence and deterministic Gate 1/2/3 decisions make the demo repeatable and auditable. An unconstrained master LLM choosing tool calls is unnecessary and could silently skip checks. Department routing is a fixed mapping, not an AI classification decision.

## Tools chosen and their role

- **Webhook:** Single entry point, explicit response node and separate path for each experimental version.
- **Code:** Input/schema checks, restoring report context after HTTP nodes, deterministic gate decisions and privacy-safe audit metadata.
- **HTTP Request:** Standard JSON interface to independently deployable agents; Docker service DNS names for local integration.
- **IF nodes:** Explicit PASS/REVIEW/REJECT branches before calling expensive downstream agents.
- **Docker network:** `municipal-net` connects n8n, Intake and Vision without exposing service ports externally; published local ports bind only to 127.0.0.1 for Windows health checks.

## Fault tolerance

- The two stateless agent HTTP requests specify timeouts and retries (`retryOnFail`, `maxTries:3`, `waitBetweenTries:1000`). That is **3 attempts maximum**, not 3 extra retries, on compatible n8n versions.
- On failure, the error continues to an adapter and safety gate; unavailable/malformed responses cannot advance as PASS.
- The code checks that external report IDs match the original report, and Vision classifications require valid enums and image evidence.
- Do **not** apply automatic retries to non-idempotent ticket creation. Member 5 should enforce unique `report_id` and return the same persisted ticket for duplicate requests, or accept a durable idempotency key.
- Circuit breaking, dead-letter queues, backoff with jitter, and persisted queueing are future enhancements, not implemented here.

## Observability and privacy

`trace` is stage-level metadata. New `audit` summarizes stage, decision, reason codes, timestamp and version, without citizen description/image/coordinates. This data is present in the workflow response and (subject to the n8n configuration) its execution history. It is **not** an independent durable audit store. Member 5 will create `ticket_events` storage. Before production, stop exposing internal audit data to citizen clients, configure execution retention, add authentication and avoid storing raw photos in n8n execution data.

## What is still simulated?

- `municipal-vision-stub` uses fixture identifiers / text keywords, not pixels.
- Intake is still the Phase 2 stub; real `uploads/*` references cannot pass without Member 3's validation and privacy processing.
- Knowledge uses a mock procedure and clearly marked mock sources, not official municipal documents.
- Tickets have `persisted:false` and `storage_status:MOCK_ONLY` and are not saved to Member 5's DB.
- `demo_mode:true` remains set internally in this workflow. This is a lab-only orchestrator. Never treat its mock-source PASS as a production source-verification PASS.

## Minimum acceptance / handoff

The offline checks cover valid report, mismatch, invalid input, Intake outage, wrong Intake ID, unverified media, Vision outage, wrong Vision ID, missing evidence, invalid confidence, uncertain classification, fake fixture result for real media, and category NONE. The live n8n workflow still needs a real import and webhook test on the Windows/Docker installation. Keep test results and screenshots showing each gate's outcome.

## Relevant references

- n8n node behavior (Retry on Fail and On Error): https://docs.n8n.io/build/understand-workflows/workflow-components/work-with-nodes/
- n8n handling errors / error workflows: https://docs.n8n.io/build/flow-logic/handle-errors-gracefully/
- n8n execution history and debugging: https://docs.n8n.io/build/understand-workflows/understand-executions/
