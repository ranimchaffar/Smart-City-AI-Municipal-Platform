import assert from 'node:assert/strict';
import fs from 'node:fs';
const root = new URL('../', import.meta.url);
const workflow = JSON.parse(fs.readFileSync(new URL('n8n/municipal-ticket-phase4.json',root),'utf8'));
const nodes = new Map(workflow.nodes.map(n=>[n.name,n]));
const code = n => {assert.ok(nodes.has(n),`missing ${n}`);return nodes.get(n).parameters.jsCode};
function exec(name,input,base){
 const fn = new Function('$input','$',code(name));
 const result = fn({first:()=>({json:structuredClone(input)})},
      nodeName=>({first:()=>({json:structuredClone(nodeName==='Input Check'?base:base)})}));
 assert.ok(Array.isArray(result)&&result.length===1,`${name} returns single-item array`);
 return result[0].json;
}
const fx=name=>JSON.parse(fs.readFileSync(new URL(`tests/${name}`,root),'utf8'));
const fixtureSet = new Set(['mock://pothole','mock://streetlight','mock://waste','mock://water_leak','mock://unrelated','mock://blurry']);
function fakeIntake(d, overrides={}){
 const isFixture=fixtureSet.has(d.media_ref);
 return {report_id:d.report_id,input_type:'IMAGE_TEXT',cleaned_description:d.description,
  language:'en',media_ref:d.media_ref,anonymized_media_ref:null,
  media_validation:isFixture?'MOCK_FIXTURE':'NOT_VERIFIED',privacy_status:'TEXT_MASKED_ONLY',
  image_anonymized:false,location:d.location??null,validity:isFixture?'MOCK_VALID':'UNKNOWN',
  errors:isFixture?[]:['REAL_MEDIA_NOT_PROCESSED'],agent_version:'intake-stub-v1',is_mock:true,...overrides};
}
function fakeVision(d,ov={}){
 const fixtures={'mock://pothole':'ROAD_DAMAGE','mock://streetlight':'STREET_LIGHTING','mock://unrelated':'NONE'};
 const category=fixtures[d.media_ref]||'NONE';
 const match=category==='ROAD_DAMAGE'?/pothole|road/i.test(d.description):category==='STREET_LIGHTING'?/streetlight|light|lamp/i.test(d.description):null;
 return {report_id:d.report_id,category,severity:'HIGH',description:d.description,
  evidence:category==='NONE'?[]:['DEMO fixture label only; pixels not analyzed'],text_image_consistent:match,
  confidence:null,uncertainty:match!==true,prompt_version:'vision-fixture-v1',agent_version:'vision-stub-v1',is_mock:true,...ov};
}
function simulate(d,{intakeOverride={},visionOverride={},intakeRaw=null,visionRaw=null}={}){
 let x=exec('Input Check',{body:d});
 if(x.decision==='PASS'){
  const orig=x;
  x=exec('Attach Intake Response',intakeRaw??fakeIntake(d,intakeOverride),orig);
  x=exec('Gate 1 - Intake',x);
  if(x.decision==='PASS'){
   const origVision=x;
   x=exec('Attach Vision Response',visionRaw??fakeVision(d,visionOverride),origVision);
   x=exec('Gate 2 - Vision',x);
   if(x.decision==='PASS'){
    x=exec('Department Rules',x);
    x=exec('Mock Knowledge',x);
    x=exec('Gate 3 - Sources',x);
    if(x.decision==='PASS')x=exec('Mock Ticket Creation',x);
   }
  }
 }
 x=exec('Audit Summary',x);
 x=exec('Format API Response',x);
 return x;
}
let testCount=0;
function check(label,d,overrides,expected,code,reason){
 const r=simulate(d,overrides);
 assert.equal(r.decision,expected,label);
 assert.equal(r.http_status,code,label);
 assert.equal(r.report_id,d.report_id,label);
 assert.equal(r.ticket===null,expected!=='PASS',`${label}: ticket rules`);
 assert.equal(r.audit.outcome,expected,label);
 assert.equal(r.audit.storage,'N8N_EXECUTION_DATA_ONLY_NOT_A_TICKET_DB');
 assert.ok(r.audit.stages.length>=1);
 assert.ok(r.audit.stages.every(e=>!Object.hasOwn(e,'description')&&!Object.hasOwn(e,'media_ref')));
 if(reason)assert.ok(r.review_reasons.includes(reason)||r.errors.includes(reason),`${label}: ${reason}`);
 if(expected==='PASS'){
  assert.equal(r.ticket.category,'ROAD_DAMAGE');assert.equal(r.ticket.department,'ROADS_DEPARTMENT');
  assert.equal(r.ticket.persisted,false);
  assert.equal(r.versions.vision,'vision-stub-v1');
 }
 console.log('PASS',label,'=>',expected,'HTTP',code);
 testCount++;
}
const pass=fx('fixtures/pass_pothole.json');
const mismatch=fx('fixtures/review_mismatch.json');
const reject=fx('fixtures/reject_missing_media.json');
const failIntake=fx('review_service_down.json');
const wrongId=fx('review_wrong_id.json');
const unverified=fx('review_unverified_real.json');
check('pothole PASS',pass,{},'PASS',200);
check('image/text mismatch REVIEW',mismatch,{},'REVIEW',202,'IMAGE_TEXT_MISMATCH_OR_UNCLEAR');
check('missing media REJECT',reject,{},'REJECT',422,'MISSING_MEDIA_REF');
check('Intake service down',failIntake,{intakeRaw:{error:'SIMULATED_INTAKE_OUTAGE'}},'REVIEW',202,'INTAKE_ENDPOINT_FAILED_OR_INVALID');
check('wrong Intake report ID',wrongId,{intakeOverride:{report_id:'DIFFERENT-ID'}},'REVIEW',202,'INTAKE_REPORT_ID_MISMATCH');
check('unverified real media',unverified,{},'REVIEW',202,'INTAKE_MEDIA_OR_PRIVACY_NOT_VERIFIED');
check('Vision service down',pass,{visionRaw:{error:'connect ECONNREFUSED'}},'REVIEW',202,'VISION_ENDPOINT_FAILED_OR_INVALID');
check('Vision wrong report ID',pass,{visionOverride:{report_id:'ANOTHER-ID'}},'REVIEW',202,'VISION_REPORT_ID_MISMATCH');
check('Vision empty evidence',pass,{visionOverride:{evidence:[]}},'REVIEW',202,'VISION_MISSING_EVIDENCE');
check('Vision invalid confidence',pass,{visionOverride:{confidence:1.5}},'REVIEW',202,'VISION_INVALID_CONFIDENCE');
check('Vision uncertain',pass,{visionOverride:{uncertainty:true}},'REVIEW',202,'VISION_UNCERTAIN');
check('Vision real media with fake stub',unverified,{
 intakeOverride:{report_id:unverified.report_id,media_validation:'VERIFIED',validity:'VALID',
  privacy_status:'ANONYMIZED',image_anonymized:true,anonymized_media_ref:'safe/redacted.jpg',errors:[],is_mock:false}
},'REVIEW',202,'VISION_MOCK_CANNOT_VALIDATE_REAL_MEDIA');
check('Vision category NONE',pass,{visionOverride:{category:'NONE'}},'REVIEW',202,'UNKNOWN_CATEGORY');
// Static graph sanity, including reachability and retry settings.
assert.equal(workflow.nodes.length,19);
const names=new Set(nodes.keys());
for (const [origin,c] of Object.entries(workflow.connections)){
 assert.ok(names.has(origin));
 for (const group of c.main??[])for(const e of group)assert.ok(names.has(e.node),`${origin} -> ${e.node}`);
}
let reached=new Set(),queue=['Citizen Webhook'];
while(queue.length){const n=queue.shift();if(reached.has(n))continue;reached.add(n);
 for(const group of workflow.connections[n]?.main??[])for(const edge of group)queue.push(edge.node);}
assert.deepEqual(new Set(names),reached);
for(const n of ['HTTP Intake','HTTP Vision']){
 assert.equal(nodes.get(n).retryOnFail,true);assert.equal(nodes.get(n).maxTries,3);
 assert.equal(nodes.get(n).waitBetweenTries,1000);assert.equal(nodes.get(n).onError,'continueRegularOutput');
}
assert.equal(nodes.get('Citizen Webhook').parameters.responseMode,'responseNode');
assert.equal(nodes.get('Citizen Webhook').parameters.path,'municipal-ticket-phase4');
assert.equal(nodes.get('Respond to Citizen').parameters.respondWith,'firstIncomingItem');
console.log(`All ${testCount} offline logic scenarios and import-graph checks passed. LIVE n8n test still required.`);
