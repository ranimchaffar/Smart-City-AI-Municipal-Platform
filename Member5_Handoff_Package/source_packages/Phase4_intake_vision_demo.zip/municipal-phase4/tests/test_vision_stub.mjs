import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {setTimeout as sleep} from 'node:timers/promises';
const p=spawn(process.execPath,['vision-stub/server.js'],{cwd:fileURLToPath(new URL('../',import.meta.url)),stdio:'pipe',env:{...process.env,PORT:'18082'}});
try{
 let ready=false;
 for(let i=0;i<40;i++){
  try{const r=await fetch('http://127.0.0.1:18082/health');if(r.ok){ready=true;break;}}catch{}
  await sleep(100);
 }
 assert.ok(ready,'stub server not started');
 async function post(body){return fetch('http://127.0.0.1:18082/vision',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});}
 const pot=await post({report_id:'RPT-001',media_ref:'mock://pothole',cleaned_description:'A deep pothole is dangerous for drivers',location:null});
 assert.equal(pot.status,200);
 const body=await pot.json();
 assert.equal(body.category,'ROAD_DAMAGE');assert.equal(body.severity,'HIGH');assert.equal(body.text_image_consistent,true);
 assert.equal(body.is_mock,true);assert.equal(body.confidence,null);
 const mis=await post({report_id:'RPT-002',media_ref:'mock://streetlight',cleaned_description:'A pothole in road'});
 const m=await mis.json();assert.equal(m.category,'STREET_LIGHTING');assert.equal(m.text_image_consistent,false);
 const real=await post({report_id:'RPT-003',media_ref:'safe/real.jpg',cleaned_description:'pothole'});
 const r=await real.json();assert.equal(r.category,'NONE');assert.equal(r.text_image_consistent,null);
 const invalid=await post({hello:'world'});assert.equal(invalid.status,400);
 console.log('Vision HTTP stub: 4 network checks passed (local Node process, not Docker).');
}finally{p.kill('SIGTERM')}
