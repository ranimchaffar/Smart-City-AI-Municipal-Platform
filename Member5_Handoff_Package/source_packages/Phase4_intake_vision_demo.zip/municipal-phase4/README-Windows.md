# Member 1 — Phase 4 (Windows 11): HTTP Vision + safer orchestration

**Prerequisite:** Your Phase 2 setup is already working: `municipal-n8n` and `municipal-intake-stub` running on Docker network `municipal-net`. **Keep the original workflows.** This package starts only a new `municipal-vision-stub` service and imports a new workflow at `/municipal-ticket-phase4`.

## What changed

The new 19-node workflow is:

`Webhook -> Input Check -> HTTP Intake -> Gate 1 -> HTTP Vision -> Gate 2 -> Department Rules -> Mock Knowledge -> Gate 3 -> Mock Ticket -> Audit Summary -> Respond to Citizen`.

As before, each gate branches immediately to the response if REJECT or REVIEW. The Intake and Vision calls have a 3-attempt retry setting (original call + up to 2 retries), 1 second between attempts, and explicit timeouts (5 s and 10 s respectively). Both continue into **fail-closed** validation on transport errors. These retries are safe **only because the agent endpoints are expected to be stateless/read-only**. Do not blindly add retries to ticket-creation POST calls (use an idempotency key / unique report ID there).

The `Audit Summary` node creates sanitized, **per-execution** metadata: report ID, final decision, reason codes, timestamps and agent versions. It is **not a durable event log** and does not create database tickets. The full webhook payload might still be present in n8n execution history, so use fictitious cases during local development.

## 1. Start the Vision demo HTTP service

1. Extract the zip into a separate folder and open the *inner* `municipal-phase4` folder containing `compose.yaml` in File Explorer.
2. Click the File Explorer address bar, type `powershell` and press Enter.
3. Run:

```powershell
docker ps
docker network inspect municipal-net
docker compose up -d
```

Only the new Vision container is created. It does not replace your old Intake container or n8n container.

4. Check the Vision service from Windows:

```powershell
curl.exe http://localhost:8002/health
```

Expected:

```json
{"status":"ok","service":"vision-stub","version":"vision-stub-v1"}
```

5. Optional: check DNS connectivity on the same Docker network:

```powershell
docker run --rm --network municipal-net curlimages/curl:latest http://municipal-vision-stub:8002/health
```

If n8n fails to reach it, make sure n8n is attached to `municipal-net`:

```powershell
docker network connect municipal-net municipal-n8n
```

An `already exists` response means the connection was already in place.

## 2. Import the NEW n8n workflow

1. Open <http://localhost:5678>.
2. Create a new workflow; **do not overwrite Phase 2**.
3. Top-right three dots -> **Import from File** -> select `n8n/municipal-ticket-phase4.json` from this folder.
4. Save, then inspect these node properties:

| Node | Important setting |
|---|---|
| `Citizen Webhook` | `POST`, path `municipal-ticket-phase4`, respond with Respond to Webhook node |
| `HTTP Intake` | `http://municipal-intake-stub:8001/intake`, timeout 5000 ms, Retry on Fail 3 total attempts |
| `HTTP Vision` | `http://municipal-vision-stub:8002/vision`, timeout 10000 ms, Retry on Fail 3 total attempts |
| `Audit Summary` | Creates metadata-only `audit` |
| `Respond to Citizen` | Respond with First Incoming Item; response code expression `{{ $json.http_status }}` |

Keep the workflow unpublished while testing. In `Citizen Webhook`, choose **Listen for Test Event** before each request.

## 3. Run five integration tests

From PowerShell in the inner `municipal-phase4` folder (where `tests/` exists):

```powershell
# A — PASS / HTTP 200, demo ticket; not persisted
curl.exe -i -X POST "http://localhost:5678/webhook-test/municipal-ticket-phase4" -H "Content-Type: application/json" --data-binary "@tests/fixtures/pass_pothole.json"

# B — REVIEW / HTTP 202, text-image mismatch
# First click Listen for Test Event again
curl.exe -i -X POST "http://localhost:5678/webhook-test/municipal-ticket-phase4" -H "Content-Type: application/json" --data-binary "@tests/fixtures/review_mismatch.json"

# C — REJECT / HTTP 422, missing image reference
# Click Listen for Test Event again
curl.exe -i -X POST "http://localhost:5678/webhook-test/municipal-ticket-phase4" -H "Content-Type: application/json" --data-binary "@tests/fixtures/reject_missing_media.json"

# D — REVIEW / HTTP 202, Intake API returns simulated HTTP 503
# Click Listen for Test Event again
curl.exe -i -X POST "http://localhost:5678/webhook-test/municipal-ticket-phase4" -H "Content-Type: application/json" --data-binary "@tests/review_service_down.json"

# E — REVIEW / HTTP 202, genuinely unverified photo reference
# Click Listen for Test Event again
curl.exe -i -X POST "http://localhost:5678/webhook-test/municipal-ticket-phase4" -H "Content-Type: application/json" --data-binary "@tests/review_unverified_real.json"
```

Expected summary:

| Case | HTTP | `decision` | Ticket |
|---|---:|---|---|
| A pothole demo | 200 | `PASS` | demo ticket, `persisted:false` |
| B mismatch | 202 | `REVIEW` | `null` |
| C missing photo | 422 | `REJECT` | `null` |
| D Intake 503 | 202 | `REVIEW` | `null` |
| E unverified photo | 202 | `REVIEW` | `null` |

In every result, inspect `audit` -> `stages`, `outcome`, and `agent_versions`. No description or image reference is intentionally written into the audit fields.

## 4. Deliberately stop Vision to verify fault handling

```powershell
docker stop municipal-vision-stub
```

Click **Listen for Test Event** again and send the pothole PASS fixture from Case A. This time expect **HTTP 202, `decision:REVIEW`, ticket null**, with `VISION_ENDPOINT_FAILED_OR_INVALID`. This demonstrates that an unreachable Vision endpoint is **not** treated as a valid classification. It may take a few seconds for retries to finish.

Restore service afterward:

```powershell
docker start municipal-vision-stub
curl.exe http://localhost:8002/health
```

## 5. Preparing Member 4's real Vision endpoint

Give Member 4 `docs/Member_4_Vision_Handoff.md`, plus `docs/contracts.md` for the whole contract. Ask for a container/service reachable from n8n on `municipal-net` and a working `POST /vision` endpoint. They must read the **actual sanitized image bytes**, not infer the category from a fixture name.

After Member 4 is ready:

1. Keep Phase 4 as a backup; duplicate the workflow in n8n.
2. Change **only the `HTTP Vision` URL** to their service, for example `http://vision-agent:8000/vision` (placeholder, not a live endpoint).
3. Keep and re-test Gate 2 response validation, especially mismatched IDs, missing evidence, unknown categories, uncertain results and image/text disagreements.
4. Test a **real image reference** only when Member 3's Intake verifies and anonymizes the actual image. Until then, the stub correctly sends real-image references to REVIEW at Gate 1.
5. Do not remove `is_mock`, `persisted`, or `demo_mode` disclosures while Knowledge/RAG and ticket storage are still simulated.

**Important:** A real POST to `/vision` must be idempotent / safe for retries; if it bills per request or has side effects, review the retry policy with Member 4 first.

## 6. What comes after Vision

Next: Member 2's `POST /knowledge` with trusted source provenance; Member 5's `POST /tickets` with idempotency and actual database persistence. Only after those integrations can you show a real ticket tracking confirmation. Do not use the internal demo department labels as verified names of a real municipality.

## Troubleshooting

- **Vision DNS error:** run `docker ps` and `docker network inspect municipal-net`; verify the service name `municipal-vision-stub` and port `8002` inside Docker.
- **No output:** make sure you used the new `/webhook-test/municipal-ticket-phase4` path and clicked Listen first.
- **Existing Intake tests failing:** check `curl.exe http://localhost:8001/health`; Phase 4 depends on the existing Phase 2 Intake container.
- **Wrong `POST /vision` response:** inspect the `HTTP Vision` and `Attach Vision Response` node outputs. A missing or invalid result intentionally becomes REVIEW.
- **A second new workflow has identical test path:** use only one listener at a time.
- **`municipal-vision-stub` already exists:** do not blindly delete it; `docker ps -a` first to see whether it belongs to this Compose project.

## Offline checks for teammates who have Node.js installed

From this folder:

```powershell
node tests/check_phase4.mjs
node tests/test_vision_stub.mjs
```

The checks verify node logic and a local HTTP stub, **not n8n live execution**. Docker-based service startup requires only Docker Desktop; it does not require Node.js on Windows.

## Safety before real citizen testing

Local demo webhooks have no authentication or abuse protection. Use fictitious data only. For real personal information or citizen images, add access controls, rate limits, safe upload storage, retention/deletion procedures, and real media anonymization; restrict n8n execution-data retention. Keep secrets in n8n credentials or environment settings, never in workflow JSON exports.
